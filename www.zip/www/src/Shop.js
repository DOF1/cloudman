Ball.Shop = function(game) {
};
Ball.Shop.prototype = {
	create: function() {
		console.log("test");
	}
};